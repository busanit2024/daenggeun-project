package com.busanit.daenggeunbackend.repository;

import com.busanit.daenggeunbackend.entity.Alba;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AlbaRepository extends MongoRepository<Alba, String> {
}