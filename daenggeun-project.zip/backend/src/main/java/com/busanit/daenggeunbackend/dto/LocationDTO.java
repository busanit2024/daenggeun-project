package com.busanit.daenggeunbackend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationDTO {
    private String sido;
    private String sigungu;
    private String emd;
}
