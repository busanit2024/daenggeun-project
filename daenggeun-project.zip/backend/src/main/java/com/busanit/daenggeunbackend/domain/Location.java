package com.busanit.daenggeunbackend.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Location {
  private String sido;
  private String sigungu;
  private String emd;
}
