package com.busanit.daenggeunbackend.constant;

public enum CommentType {
  COMMENT, REPLY //댓글, 답글
}
