import React from "react";

export default function MyProfileView (props) {
    return (
        <Wrapper>
            
        </Wrapper>
    );

}