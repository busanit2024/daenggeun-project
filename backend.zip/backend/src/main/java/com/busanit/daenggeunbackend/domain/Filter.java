package com.busanit.daenggeunbackend.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Filter {
  private String name;
  private String value;
}
