package com.busanit.daenggeunbackend.constant;

public enum GroupRange {
  NEAR, FAR, VERY_FAR, ALL;
}
