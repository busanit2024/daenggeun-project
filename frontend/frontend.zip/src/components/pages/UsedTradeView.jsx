import UsedTrade from "./UsedTrade";
import React from "react";
import styled from "styled-components";
import { useState, useContext } from "react";
import Button from "../ui/Button";

const UsedTradeView = () => {
    return <div>중고거래 화면</div>;
};

export default UsedTradeView;