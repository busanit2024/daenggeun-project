import React from "react";
import styled from "styled-components";
import Button from "../ui/Button";
import Filter from "../ui/Filter";
import Toolbar from "../Toolbar";

const UsedTrade = () => {
    return (
        <div>
            <Toolbar />
            <p>안녕?</p>
        </div>
    )
};

export default UsedTrade;